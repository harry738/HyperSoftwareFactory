# HyperSoftwareFactory brand system

**Build with agents. Verify with evidence.**

A retro arcade and terminal factory floor. Work enters as an issue, moves through specialist stations, and leaves as an inspected change. The original supplied artwork is the visual authority. The product is a working pilot, not a promise of full autonomy.

## Design tokens

| Role | Hex | Use |
|---|---|---|
| Base navy | `#0b1220` | Background |
| Raised navy | `#142238` | Raised surfaces |
| Panel | `#1c3048` | Standard station |
| Verified panel | `#102e2b` | Verified or successful outcome |
| Grid | `#203048` | 40px blueprint grid |
| Border | `#31415b` | Frames and dividers |
| Connector | `#466080` | Ordinary connectors |
| Mint | `#54e0b1` | HYPER, verified, pass, merge, positive, cursor |
| Periwinkle | `#8eabff` | Standard stages, icons, CHANGES, non-success alerts |
| Amber | `#f5b14c` | Explicit human handoff / escalation only |
| Text | `#edf3fc` | Titles and readable primary text |
| Text 2 | `#b8c6d9` | Body and subtitles |
| Muted | `#91abc7` | Labels |

No red, gradients or glow in static artwork. A functional error does not automatically mean human handoff. Use explicit text labels as well as colour. A proposed or unverified capability never gets a verified mint status; use periwinkle and dashed lines for target-state work.

## Typography and graphic language

- Wordmark: **HYPER** in mint, **SOFTWARE FACTORY** in white; uppercase chunky pixel glyphs. Use the supplied original banner, not a generic recreation.
- Display/diagram headings: uppercase, wide-tracked pixel or monospace. Font stack: `Press Start 2P`, `Pixelify Sans`, `Lucida Console`, `Consolas`, `monospace` (local availability; no external font dependency). Body: Arial/Helvetica/sans-serif.
- Grid: 40px, navy; flat square panels, thin periwinkle top rules; mint only for verified outcomes. Use pixel document, chip/check and branch icons.
- Labels: ISSUE / SPEC / BUILD / VERIFY / MERGE. Technical identifiers and filenames retain their real case. Native GitHub Markdown headings remain readable and linkable.
- Flow: left to right where practical, rework underneath, labelled **UP TO 3 ROUNDS**. Use actual stage names: intake, spec, build, gate, review (code, security, UI, UX), approver. Distinguish merge permitted by policy from a human decision.
- Motion: mint pulses along connectors, sequential highlighting and seamless loops. Preserve the supplied MP4 as source; embed its converted GIF in GitHub README. Where a browser supports it, animated SVG is an alternative for newly authored vector illustrations. Provide alt text and a non-motion textual explanation; dashboard animation respects reduced-motion preferences.

## Mermaid standard

Canonical tokens: [mermaid-theme.json](mermaid-theme.json). Use `theme: base` with embedded `themeVariables` in each fenced diagram, because GitHub does not load a repository-wide Mermaid configuration file. Use Mermaid frontmatter or the supported `init` directive, never both. The release uses frontmatter. Keep actual diagram semantics and arrows intact; not every architecture diagram is a runtime data flow. Native Mermaid does not guarantee custom pixel fonts, a 40px grid, or top-only panel borders on GitHub. Use branded artwork for exact graphic fidelity; retain Mermaid for editable, accessible technical diagrams.

Standard classes:

```text
classDef stage fill:#1c3048,stroke:#8eabff,color:#edf3fc,stroke-width:2px
classDef verified fill:#102e2b,stroke:#54e0b1,color:#edf3fc,stroke-width:2px
classDef human fill:#142238,stroke:#f5b14c,color:#edf3fc,stroke-width:2px
classDef planned fill:#142238,stroke:#8eabff,color:#edf3fc,stroke-dasharray:5 4
```

For flowcharts, use `flowchart LR` unless a vertical layout improves comprehension. Use `linkStyle` for semantic edges when supported. Keep planned capabilities dashed and human-only amber. Mermaid labels should be concise and retain the correct stage/role. Sequence diagrams use the same actor, signal and note tokens from the canonical theme.

## Source assets

- [Hero banner](../assets/banner-retro-teal-hyper.png)
- [Factory floor illustration](../assets/banner-assembly-line-retro-sharp.png)
- [Repository map](../assets/diagram-architecture-retro-sharp.png)
- [Workflow original MP4](../assets/diagram-workflow-retro-motion.mp4)
- [README-compatible animated GIF](../assets/diagram-workflow-retro-motion.gif)

The factory floor and repository map are illustrative, not exhaustive or current runtime evidence. The technical diagrams and build plan are authoritative for capabilities and current status.

## Review checklist

Before merging any branded documentation or UI change, confirm the palette, status semantics, readable labels, valid Mermaid syntax, alt text, accurate links, light/dark GitHub rendering, reduced motion on app pages and mobile layout. Do not change archived documentation or third-party vendored material merely to restyle it.

References: [Mermaid theming](https://mermaid.js.org/config/theming.html), [GitHub diagram rendering](https://docs.github.com/en/get-started/writing-on-github/working-with-advanced-formatting/creating-diagrams).
