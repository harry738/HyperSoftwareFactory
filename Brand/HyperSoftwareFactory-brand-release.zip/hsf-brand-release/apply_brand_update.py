#!/usr/bin/env python3
"""Apply the HyperSoftwareFactory brand release to a clean local Git checkout.
No network, no external packages, no automatic commit/push. Reviewed baseline:
956975ec28b5c0280b644e371dbfb8a66dde1dd0. Unrelated later commits are allowed
when the four edited files still have the reviewed Git blob IDs.
"""
import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent
BASELINE = {
    'README.md': 'afac53e4f7bf1ea6306d282364323ca7ea22de66',
    'config/README.template.md': 'f48e3282c9e8889d96d64332fb566b2b7d0e2c7b',
    'factory/dashboard.html': '848503e9068dccc83e0171a7b30350d2046c4b5c',
    'AGENTS.md': 'ccd7ddc1e5e9962d438e7390cb6120ba42ba42b3',
}
ASSETS = (
    'docs/assets/banner-retro-teal-hyper.png',
    'docs/assets/banner-assembly-line-retro-sharp.png',
    'docs/assets/diagram-architecture-retro-sharp.png',
    'docs/assets/diagram-workflow-retro-motion.mp4',
    'docs/assets/diagram-workflow-retro-motion.gif',
    'docs/brand/README.md',
    'docs/brand/mermaid-theme.json',
)
ARCHIVE = 'docs/archive/README-pre-brand-afac53e.md'
THEME = json.loads((BUNDLE / 'docs/brand/mermaid-theme.json').read_text())
FENCE = re.compile(r'(?m)^([ \t]*)```mermaid[ \t]*\r?\n(.*?)(?<=\n)\1```[ \t]*(?=\r?$)', re.S | re.I)
STAGE = '    classDef stage fill:#1c3048,stroke:#8eabff,color:#edf3fc,stroke-width:2px'
VERIFIED = '    classDef verified fill:#102e2b,stroke:#54e0b1,color:#edf3fc,stroke-width:2px'
HUMAN = '    classDef human fill:#142238,stroke:#f5b14c,color:#edf3fc,stroke-width:2px'
PLANNED = '    classDef planned fill:#142238,stroke:#8eabff,color:#edf3fc,stroke-width:2px,stroke-dasharray:5 4'


def git(root, *args, binary=False):
    return subprocess.check_output(['git', '-C', str(root), *args], text=not binary)


def replace_once(s, old, new):
    if s.count(old) != 1:
        raise ValueError(f'Expected one occurrence of {old[:100]!r}; found {s.count(old)}')
    return s.replace(old, new, 1)


def frontmatter():
    # JSON scalar syntax is valid YAML. No template substitution characters.
    lines = ['---', 'config:', '  theme: base', '  themeVariables:']
    for key, value in THEME['themeVariables'].items():
        lines.append(f'    {key}: {json.dumps(value)}')
    lines += ['  flowchart:', '    curve: stepAfter', '    htmlLabels: true', '---']
    return '\n'.join(lines)


def brand_diagram(body, kind):
    # Strip original styling only; retain existing topology/decision labels.
    body = re.sub(r'(?m)^\s*classDef\s+[^\n]+\n?', '\n', body)
    body = re.sub(r'(?m)^\s*class\s+[^\n]+\n?', '\n', body).strip()
    if kind == 'workflow':
        # Distinguish gates from verified outcomes. Operator handoff only is amber.
        substitutions = {
            'GitHub issue': '1 ISSUE<br/>GitHub', 'Intake': '2 INTAKE',
            'Specification': '3 SPEC', 'Builder / worktree': '4 BUILD<br/>Worktree',
            'Deterministic gate': '5 GATE<br/>Deterministic checks',
            'Independent reviewers': '6 REVIEW<br/>Code / Security / UI / UX',
            'Approver / policy': '7 APPROVER<br/>Policy', 'Operator': 'ESCALATE<br/>Human',
            'Pull request / merge': 'MERGE<br/>Policy permits',
        }
        for a,b in substitutions.items(): body = body.replace('"'+a+'"','"'+b+'"')
        body = body.replace('R -- CHANGES --> B', 'R -- "CHANGES / up to 3 rounds" --> B')
        body = body.replace('G -- FAIL --> B', 'G -- "FAIL / rework" --> B')
        body = body.replace('H --> P', 'H -- "If approved" --> P')
        body += '\n'+'\n'.join([STAGE,VERIFIED,HUMAN,'    class I,T,S,B,G,R,A stage','    class P verified','    class H human',
            '    linkStyle 4,6 stroke:#8eabff,stroke-width:2px',
            '    linkStyle 5,9 stroke:#54e0b1,stroke-width:2px',
            '    linkStyle 8 stroke:#f5b14c,stroke-width:2px'])
    elif kind == 'central':
        body = body.replace('flowchart TB','flowchart LR',1)
        body += '\n'+'\n'.join([STAGE,'    class C,F,A,B,WA,WB,GA,GB,E stage'])
    elif kind == 'target':
        body = body.replace('S["Signals"] --> I', 'S["Signals"] -.-> I').replace('V["Verify"] --> D["Deploy"] --> M["Monitor"] --> L["Learn"]', 'V["Verify"] -.-> D["Deploy"] -.-> M["Monitor"] -.-> L["Learn"]')
        body += '\n'+'\n'.join([STAGE,PLANNED,'    class I,T,SP,B,V stage','    class S,D,M,L,G1,G2,G3,K planned'])
    elif kind == 'autonomy':
        # All levels remain unearned; no mint or amber on the current marker.
        body += '\n'+'\n'.join([STAGE,PLANNED,'    class L1,L2,L3,L4 planned','    class NOW stage'])
    elif kind == 'template':
        body += '\n'+STAGE+'\n    class U,A,S,D stage'
    else:
        raise ValueError(f'Unexpected Mermaid diagram: {kind}')
    return frontmatter()+'\n'+body+'\n'


def style_mermaid(text, kinds):
    matches = list(FENCE.finditer(text))
    if len(matches) != len(kinds):
        raise ValueError(f'Expected {len(kinds)} Mermaid diagrams, found {len(matches)}')
    for match, kind in reversed(list(zip(matches,kinds))):
        text = text[:match.start()]+'```mermaid\n'+brand_diagram(match[2], kind)+'```'+text[match.end():]
    return text


def readme(text):
    text = replace_once(text, 'docs/assets/readme-banner.svg','docs/assets/banner-retro-teal-hyper.png')
    text = replace_once(text, '**An open-source, agent-driven software factory. Governed by code. Verified with evidence.**', '**Build with agents. Verify with evidence.**')
    text = replace_once(text, 'Convert labelled GitHub issues into scoped changes, independently reviewed pull requests and operator-controlled decisions, across projects from one central factory.', 'A free, open-source software factory. Turn labelled GitHub issues into independently reviewed pull requests, with operator-controlled decisions across projects.')
    text = text.replace('labelColor=172033','labelColor=142238').replace('status-pilot-54e0b1','status-pilot-8eabff').replace('engine-GPLv3-54e0b1','engine-GPLv3-8eabff')
    text = replace_once(text, 'docs/assets/factory-flow.gif','docs/assets/diagram-workflow-retro-motion.gif')
    text = replace_once(text, '<sub>Illustrative flow. The scripts and state machine define actual job transitions.</sub>', '<sub>ISSUE / SPEC / BUILD / VERIFY / MERGE — illustrative workflow. Actual transitions are defined by the engine. <a href="docs/assets/diagram-workflow-retro-motion.mp4">Original animation (MP4)</a>.</sub>')
    text = replace_once(text, '## Quick start\n', '<div align="center">\n\n<img src="docs/assets/banner-assembly-line-retro-sharp.png" alt="Retro factory floor with agent stations for planning, coding, testing, reviewing and verifying work before a merge." width="100%" />\n\n<sub>Illustration of the factory concept, not a claim of unattended production merging.</sub>\n\n</div>\n\n## Quick start\n')
    text = replace_once(text, '## Contents\n', '## Contents\n\n<div align="center">\n\n<img src="docs/assets/diagram-architecture-retro-sharp.png" alt="Illustrative repository map: factory engine, Claude agents and skills, scripts, reference documentation and GitHub CI workflows." width="100%" />\n\n<sub>REPO MAP — illustrative overview. The table below is the current source map.</sub>\n\n</div>\n\n')
    text = replace_once(text, '## Contributing\n', '## Contributing\n\nAll new documentation, diagrams and interface changes follow the [HyperSoftwareFactory brand system](docs/brand/README.md) and its [Mermaid theme](docs/brand/mermaid-theme.json).\n')
    return style_mermaid(text, ['workflow','central','target','autonomy'])


def template(text):
    text = text.replace('HyperSoftwareFactory-D97757','HyperSoftwareFactory-8eabff?style=flat-square&labelColor=142238')
    return style_mermaid(text,['template'])


def dashboard(text):
    # Only modify CSS and header presentation, never the JS state/logic.
    before, marker, after = text.partition('</style>')
    if not marker: raise ValueError('Dashboard style tag missing')
    values = {'bg':'#0b1220','panel':'#142238','card':'#1c3048','card-hover':'#203048',
              'line':'#31415b','text':'#edf3fc','muted':'#b8c6d9','faint':'#91abc7',
              'active':'#8eabff','pass':'#54e0b1','changes':'#8eabff','human':'#f5b14c','merged':'#54e0b1'}
    for token, value in values.items():
        before, n = re.subn(r'(--'+re.escape(token)+r':\s*)#[0-9a-fA-F]{6}(;)', lambda m:m[1]+value+m[2], before)
        if n!=1: raise ValueError(f'Dashboard token --{token} changed')
    before=replace_once(before, 'font: 14px/1.5 -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif;', 'font: 14px/1.5 Arial, Helvetica, sans-serif;')
    before += '''
  /* HyperSoftwareFactory brand: visual only. */
  :root { --grid: #203048; --display: "Press Start 2P", "Pixelify Sans", "Lucida Console", Consolas, monospace; }
  body { background-image: linear-gradient(var(--grid) 1px, transparent 1px), linear-gradient(90deg, var(--grid) 1px, transparent 1px); background-size: 40px 40px; }
  header h1 { font-family: var(--display); text-transform: uppercase; letter-spacing: .07em; font-size: clamp(16px, 2.4vw, 22px); line-height: 1.5; }
  header h1 .hyper { color: var(--pass); }
  header h1::after { content: ""; display: inline-block; background: var(--pass); width: .65em; height: .9em; margin-left: .5em; vertical-align: -.1em; animation: cursor-blink 1.2s steps(1) infinite; }
  @keyframes cursor-blink { 0%, 49% { opacity: 1; } 50%, 100% { opacity: 0; } }
  .col-head h2, .md h1, .md h2, .md h3, .md h4, .d-head h3 { font-family: var(--display); text-transform: uppercase; letter-spacing: .04em; }
  .col-head { border-bottom-color: var(--active); }
  .card, .tab, .banner, .chip, .close, .file, .md code, .md pre, .md .summary, .verdict { border-radius: 0; }
  .card { border-top: 2px solid var(--active); }
  .card.human { box-shadow: none; border-color: var(--human); }
  .col.merged-col .card { border-top-color: var(--merged); background: #102e2b; }
  .col.merged-col .col-head { border-bottom-color: var(--merged); }
  .status .dot, .pulse, .file .v { border-radius: 0; }
  .status.error, .banner, .chip.FAIL, .chip.bad, .meta .risk-high { color: var(--changes); }
  .status.error .dot { background: var(--changes); }
  .banner, .chip.bad { border-color: var(--changes); }
  .chip.FAIL { background: color-mix(in srgb, var(--changes) 16%, transparent); }
  .chip.PASS { background: #102e2b; }
  .v.stop { background: var(--changes); }
  .verdict.stop { color: var(--changes); background: color-mix(in srgb, var(--changes) 16%, transparent); }
  .card:hover { transform: none; }
  @media (prefers-reduced-motion: reduce) { header h1::after { animation: none; } .card, .drawer, .scrim { transition: none; } }
'''
    after=replace_once(after,'<h1>Software factory</h1>','<h1><span class="hyper">Hyper</span>Software Factory</h1>')
    before=before.replace('<title>Software Factory</title>','<title>HyperSoftwareFactory</title>')
    return before+marker+after


def agents(text):
    return replace_once(text,'## Public repo\n','## Brand and diagrams\n\nFollow [the brand system](docs/brand/README.md) for README, documentation diagrams and interface changes. Embed the canonical [Mermaid theme](docs/brand/mermaid-theme.json) in every first-party Mermaid block; mint denotes verified outcomes, periwinkle standard work or planned capabilities, and amber explicit human handoff only. Preserve real technical terms and do not alter archived or vendored material for styling.\n\n## Public repo\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo',type=Path)
    parser.add_argument('--check',action='store_true',help='Validate and list changes without writing')
    parser.add_argument('--stage',action='store_true',help='Stage only these files after successful application')
    a=parser.parse_args()
    root=Path(git(a.repo.resolve(),'rev-parse','--show-toplevel').strip())
    if git(root,'status','--porcelain'):
        raise SystemExit('Checkout is not clean. Commit or stash your changes first; nothing written.')
    for path,expected in BASELINE.items():
        actual=git(root,'rev-parse','HEAD:'+path).strip()
        if actual!=expected: raise SystemExit(f'{path} changed since review ({actual}). Rebase the brand update manually; nothing written.')
    # Check all tracked first-party Markdown for unexpectedly added Mermaid blocks.
    mermaid_files={}
    for path in git(root,'ls-files','-z').split('\0'):
        if not path or path.startswith('docs/archive/') or (path.startswith('.claude/skills/') and not path.startswith('.claude/skills/factory/')) or not path.lower().endswith('.md'): continue
        n=len(list(FENCE.finditer((root/path).read_text(encoding='utf-8'))))
        if n: mermaid_files[path]=n
    if mermaid_files!={'README.md':4,'config/README.template.md':1}:
        raise SystemExit(f'Mermaid inventory changed: {mermaid_files}. Review before applying; nothing written.')
    transforms={'README.md':readme,'config/README.template.md':template,'factory/dashboard.html':dashboard,'AGENTS.md':agents}
    rendered={p:fn((root/p).read_text(encoding='utf-8')) for p,fn in transforms.items()}
    new_paths=[ARCHIVE,*ASSETS]
    for p in new_paths:
        if (root/p).exists(): raise SystemExit(f'Destination already exists: {p}. Nothing written.')
    for p in ASSETS:
        if not (BUNDLE/p).is_file(): raise SystemExit(f'Bundle missing {p}. Nothing written.')
    print('Files to modify:',*rendered,sep='\n  ')
    print('Files to add:',*new_paths,sep='\n  ')
    print('Mermaid diagrams:',mermaid_files)
    if a.check: print('Preflight passed. No changes written.');return
    archive=root/ARCHIVE;archive.parent.mkdir(parents=True,exist_ok=True)
    archive.write_bytes(git(root,'show','HEAD:README.md',binary=True))
    for p in ASSETS:
        dest=root/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(BUNDLE/p,dest)
    for p,value in rendered.items():
        (root/p).write_bytes(value.encode('utf-8'))
    if a.stage: git(root,'add','--',*rendered,*new_paths)
    print('Applied. Review git diff'+(' --cached' if a.stage else '')+' and run bash scripts/test.sh before committing.')

if __name__=='__main__': main()
