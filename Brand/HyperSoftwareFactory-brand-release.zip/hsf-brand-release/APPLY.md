# Apply the HyperSoftwareFactory brand release

The bundle contains the original supplied PNGs and MP4, a GIF conversion of that animation, canonical brand rules and a Git-aware application script. It is prepared against GitHub `main` at `956975ec28b5c0280b644e371dbfb8a66dde1dd0`. It preserves the current README's technical content, archives its exact Git blob, and changes the four existing README Mermaid diagrams and the onboarding template diagram. Dashboard changes are CSS/header presentation only; agent logic is untouched.

## Apply locally

Unzip outside the target checkout. In the repository, update to the reviewed version (or a later version with unchanged affected files), and ensure the working tree is clean. Run the script with the path to the checkout:

```bash
python /path/to/hsf-brand-release/apply_brand_update.py /path/to/HyperSoftwareFactory --check
python /path/to/hsf-brand-release/apply_brand_update.py /path/to/HyperSoftwareFactory --stage
cd /path/to/HyperSoftwareFactory
git diff --cached --stat
git diff --cached --check
bash scripts/test.sh
# Optional: generate a portable binary-inclusive Git patch outside the checkout.
git diff --cached --binary > ../hyper-software-factory-brand.patch
# After reviewing the changes:
git commit -m "docs: apply HyperSoftwareFactory retro brand system"
git push origin HEAD
```

The script refuses dirty working trees, changed baseline files, unexpected first-party Mermaid inventory and conflicting asset paths before writing. It does not commit or push. If GitHub main has advanced and the edited files changed, manually rebase rather than overriding the hash check. The archive is an exact historical copy, so its original relative links are not rewritten. Archived and vendored material is excluded from the restyling.

## Commit-ready file list

| Operation | Path |
|---|---|
| Modify | `README.md` |
| Modify | `config/README.template.md` |
| Modify | `factory/dashboard.html` |
| Modify | `AGENTS.md` |
| Add | `docs/archive/README-pre-brand-afac53e.md` |
| Add | `docs/assets/banner-retro-teal-hyper.png` |
| Add | `docs/assets/banner-assembly-line-retro-sharp.png` |
| Add | `docs/assets/diagram-architecture-retro-sharp.png` |
| Add | `docs/assets/diagram-workflow-retro-motion.mp4` |
| Add | `docs/assets/diagram-workflow-retro-motion.gif` |
| Add | `docs/brand/README.md` |
| Add | `docs/brand/mermaid-theme.json` |

The previous SVG/GIF assets remain untouched for historical references. The bundle files `APPLY.md` and `apply_brand_update.py` are release tooling, not files copied into the project.

## Verification boundaries

The reviewed live files and Mermaid blocks were inspected through GitHub. Exact original raster artwork and MP4 are retained. The animated GIF is converted to 960px wide, 12fps and an infinite loop; colour quantisation is required by GIF. The application script is tested on a synthetic Git checkout reflecting reviewed anchors/diagrams; final repository and GitHub-rendered visual checks must be run after application. GitHub controls native Markdown typography and Mermaid rendering; the brand uses the original pixel artwork plus a local-font fallback stack. No custom font is installed or fetched. The update does not change underlying factory functionality or certify roadmap completion.
